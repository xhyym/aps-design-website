# APS Design Pro 编码规则（适配 Codex / Cursor / Trae / GitHub Copilot 等支持 AGENTS.md 的工具）

> 使用说明：把本文件重命名为 `AGENTS.md` 放到项目根目录（或 `~/.codex/AGENTS.md` 全局生效）。
> 完整版 Skill（组件索引、类型、图标、模式）见 `references/` 目录。

## 技术栈

- Vue 3（Composition API + `<script setup>`）+ TypeScript + Vite
- UI 组件库：**aps-design-pro**（v0.3.1，179 个公开组件，仅此一家，不要引入其他 UI 库）

## 组件使用铁律

1. 组件名一律 `App` 前缀 PascalCase（`AppButton`、`AppDataTable`、`AppFormField`），从 `aps-design-pro` 包根按需导入。
2. 使用组件前必须引入样式：`import "aps-design-pro/style.css";`
3. 图标名只允许 `IconName` 的 50 个合法字面量（`grid`、`settings`、`users`、`shield`、`search`、`plus`、`download`、`chart`、`trash`、`edit`、`check`、`warning`、`close`、`refresh`、`arrow-right`、`panel`、`menu`、`columns` 等）。写错会 TS 报错。
4. 类型可选择性导入：`import { AppDataTable, type DataTableColumn } from "aps-design-pro";`
   - 可导入：`DataTableColumn`、`DataTableSort`、`ChartSeries`、`TreeOption`、`SelectOption`、`TablePreference`、`UploadFileItem`、`ControlSize`、`IconName` 等
   - **不可导入**（内联对象即可）：`NavigationItem`、`ContextMenuItem`、`DropdownItem`、`CommandPaletteItem` 等，传数组时 `icon` 字段加 `as const`
5. 组件不替业务发请求：`loading`/`disabled`/数据请求由页面控制。
6. 有状态组件优先 `v-model` / `v-model:xxx`（如 `v-model:selected-keys`、`v-model:page`、`v-model:expanded-keys`）。

## 常见组合模板

- **数据表格页**：`AppTableToolbar`（`#bulk` 批量操作层）→ `AppDataTable`（`row-key` 必填、`columns: DataTableColumn<Row>[]`）→ `AppPagination`（`v-model:page` + `v-model:page-size` + `total` 必填）
- **表格行操作**：`action-label="操作"` + `#actions` 插槽；批量编辑用 `AppTableBatchEditor`
- **弹窗表单**：`AppDialog` / `AppDrawer`（`v-model` 必填）+ `AppForm`/`AppFormField` + `#footer` 插槽放确认/取消
- **删除确认**：`AppPopconfirm`（`#trigger="{ toggle }"` + `@confirm`）
- **搜索筛选**：`AppSearchBar`（`#actions` 放查询按钮，`@submit` 触发）+ `AppTableColumnFilters` / `AppTableHeader`
- **图表卡片**：`AppChartCard` / `AppLineChart` / `AppBarChart` / `AppDonutChart` / `AppRingChart`（`series: ChartSeries[]` = `{ name, data: number[] }` + `categories: string[]`）
- **反馈**：`AppAlert` / `AppToast` / `AppResult` / `AppSkeleton` / `AppEmptyState` / `AppStatePanel`

## 常见陷阱

- `AppDialog`/`AppDrawer`/`AppPopconfirm`/`AppDropdown`/`AppContextMenu`/`AppCommandPalette`/`AppFastEnter`/`AppGlobalSearch` 的 `modelValue` 多为**必填**，必须挂 `v-model`。
- `AppTableBatchEditor` 的 `fields` 需注解 `DataTableBatchEditField<Row>[]`（先定义 `interface Row`），否则泛型 key 报错。
- 回调签名：`UploadBeforeUpload` 返回 `boolean | Promise<boolean>`（不要返回字符串）；`DataTableEditValidator` 为 `(context, value) => void | string | Promise<...>`。
- `v-model` 不能绑定插槽作用域变量；可编辑表格自定义编辑器用 `column.editor` 配置（`{ type: "text"|"number"|"select", options? }`）。

## 完整参考

- 组件全量索引、核心类型、图标清单、8 个组合模式：见本包 `references/` 目录
- 组件详细 API：`node_modules/aps-design-pro/dist/types/components/<category>/<Component>.vue.d.ts`
