# 组件总览（177 个公开组件，9 大分类）

> 本索引由 aps-design-pro v0.3.1 官网文档自动生成。组件名一律为 `App` 前缀 PascalCase；
> 引入自 `aps-design-pro` 包根导出，样式引入 `aps-design-pro/style.css`。

## base — 基础组件（15）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppAvatar` | `AppAvatar` 用于稳定展示用户、成员或实体的身份入口。它内置图片失败回退、姓名缩写和图标回退，不需要业务层为了加载异常再维护一套条件渲染。 | `base/头像` |
| `AppAvatarGroup` | `AppAvatarGroup` 处理成员头像的重叠排列和溢出计数。页面只提供成员数据，不必计算“显示前几人”或手动拼接 `+N`。 | `base/头像组` |
| `AppBadge` | `AppBadge` 用于将未读数量、待处理数量或“有更新”状态附着在一个明确的业务入口上。它只负责状态提示，不处理点击、跳转或数据请求；这些行为应由被包裹的组件承担。 | `base/徽标` |
| `AppButton` | `AppButton` 负责页面中单个明确的动作，例如保存、提交、创建、确认、取消。组件不发起请求——加载态、禁用态全部由页面控制。 | `base/按钮` |
| `AppButtonGroup` | `AppButtonGroup` 把一组同层级的 `AppButton` 拼成工具条，只负责边框、方向与分组语义，不发起请求。 | `base/按钮组` |
| `AppButtonMore` | `AppButtonMore` 把低频、辅助、危险操作收进下拉抽屉，给工具栏留出主任务。组件不发起请求——展开态由页面控制。 | `base/更多按钮` |
| `AppButtonTable` | `AppButtonTable` 是表格行内操作的轻量编排器：默认插槽放高频动作，`moreItems` 放低频动作。它保持操作区右对齐与统一间距，避免各列手写不同的按钮排列规则。 | `base/表格按钮` |
| `AppConfigProvider` | `AppConfigProvider` 为子组件提供默认尺寸、禁用态、层级基准和语言环境。它使用 `display: contents`，不会额外产生可见布局盒子，适合放在应用根部或某个局部工作区的边界。 | `base/全局配置` |
| `AppGlobalComponent` | `AppGlobalComponent` 是一个不参与布局的兼容容器。它只渲染默认插槽，根元素使用 `display: contents`，不会形成额外的视觉盒子。 | `base/全局组件容器` |
| `AppIcon` | `AppIcon` 提供组件库内置的线性 SVG 图标。图标使用 `currentColor`，颜色由外层文字色或组件状态决定，不需要单独传入颜色值。 | `base/图标` |
| `AppIconButton` | `AppIconButton` 是只有图标、仍保持明确可访问名称的操作入口。它把 `label` 同时写入 `aria-label` 和浏览器提示文本，适合刷新、筛选、关闭、设置等空间受限的常见动作。 | `base/图标按钮` |
| `AppLink` | `AppLink` 用于文案中的跳转入口，统一文本色、下划线策略、键盘焦点与新窗口安全属性。它渲染原生 `<a>`，并不替代 Vue Router 的路由组件。 | `base/链接` |
| `AppSvgIcon` | `AppSvgIcon` 是 `AppIcon` 的行内包装组件，提供统一的垂直对齐和可选 `aria-label`。适用于内容区的图标与文字组合。 | `base/SVG 图标` |
| `AppText` | `AppText` 用于统一业务页面中的文字语义、字号、字重与截断策略。它不负责容器间距或标题层级；布局间隔由父容器决定，真正的页面标题仍应使用合适的原生语义标签。 | `base/文本` |
| `AppThemeSvg` | `AppThemeSvg` 是 `AppSvgIcon` 的兼容别名，Props 会原样转交给 `AppSvgIcon`。它不维护另一套图标资源，也没有额外主题计算逻辑。 | `base/主题 SVG 图标` |

## form — 表单与选择（40）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppAutocomplete` | `AppAutocomplete` 在文本输入过程中给出匹配建议，既能处理本地选项，也能协调远程查询的防抖、取消和异常状态。 | `form/联想输入` |
| `AppCalendar` | `AppCalendar` 是直接嵌入页面的月视图选择器，适合排期、签到和日期概览中的单日选择。 | `form/日历` |
| `AppCalendarPanel` | `AppCalendarPanel` 提供无外框的日期网格，适合嵌入弹层、排期侧栏或自定义日期组合控件。 | `form/日历面板` |
| `AppCascader` | `AppCascader` 用路径数组表达层级选择，适合地区、部门、课程目录等存在父子结构的数据。 | `form/级联选择器` |
| `AppCascaderPanel` | `AppCascaderPanel` 直接展示分级选项列，适合区域、类目等需要连续浏览层级的选择。 | `form/级联面板` |
| `AppCheckbox` | `AppCheckbox` 用于独立布尔确认、全选状态和带文字说明的多项勾选入口。它管理单项选中、半选与禁用状态；多选值集合使用 `AppCheckboxGroup`。 | `form/复选框` |
| `AppCheckboxGroup` | `AppCheckboxGroup` 用稳定值数组管理多个可选项，支持数量限制、按钮和卡片两种业务展示方式。 | `form/复选框组` |
| `AppColorPicker` | `AppColorPicker` 以紧凑触发器打开颜色面板，输出由 `format` 统一控制的颜色字符串。 | `form/颜色选择器` |
| `AppColorPickerPanel` | `AppColorPickerPanel` 是直接嵌入页面的颜色编辑面板。 | `form/颜色面板` |
| `AppDatePicker` | `AppDatePicker` 通过紧凑输入框打开日期面板，并可统一选择日期、月份、年份、周或多个日期。 | `form/日期选择器` |
| `AppDatePickerPanel` | `AppDatePickerPanel` 是没有输入框与外层浮层的日期、月份、年份和周选择面板，供业务组合使用。 | `form/日期选择面板` |
| `AppDateRangePicker` | `AppDateRangePicker` 将两个日期端点封装为一个受控对象，可选择日期、月份或年份范围。 | `form/日期范围选择器` |
| `AppDateTimePicker` | `AppDateTimePicker` 将日期日历与时间面板组合为一个 ISO 日期时间输入控件。 | `form/日期时间选择器` |
| `AppDateTimeRangePicker` | `AppDateTimeRangePicker` 在同一面板中选择起止日期和时间，并始终输出结构化范围对象。 | `form/日期时间范围选择器` |
| `AppFilterBar` | `AppFilterBar` 用弹性网格承载列表筛选字段，并统一查询、重置和高级筛选的操作位置。 | `form/筛选栏` |
| `AppForm` | `AppForm` 通过 `FormItem` 配置生成栅格化字段、规则校验、条件显隐与提交重置流程。 | `form/配置式表单` |
| `AppFormField` | `AppFormField` 为任意控件补齐标签、必填标记、帮助说明、错误信息和关联的无障碍描述。 | `form/表单字段容器` |
| `AppInput` | `AppInput` 是单行文本输入的基础组件，统一处理尺寸、清空、密码可见性、字符计数和输入状态。它只管理输入交互，字段校验规则和提交时机仍由业务表单决定。 | `form/输入框` |
| `AppInputOTP` | `AppInputOTP` 将一次性验证码拆为可连续输入、粘贴和键盘导航的输入格，同时对最终提交值做字符规范化。 | `form/验证码输入` |
| `AppInputTag` | `AppInputTag` 用可编辑标签集合承接自由输入，支持回车、分隔符和粘贴批量创建，并自动忽略重复值。 | `form/标签输入` |
| `AppMention` | `AppMention` 在多行文本中识别触发字符，并让用户从受控候选项中插入成员、专题等引用内容。 | `form/提及输入` |
| `AppNumberInput` | `AppNumberInput` 用于数量、价格、时长、比例等数值录入。组件统一处理步长、精度、边界、键盘上下键和格式化显示，避免业务页手写不一致的数值归一化逻辑。 | `form/数字输入框` |
| `AppRadio` | `AppRadio` 用于一组选项中的唯一选择。它支持常规、按钮和卡片三种呈现方式；数据驱动的一组单选项使用 `AppRadioGroup`。 | `form/单选框` |
| `AppRadioGroup` | `AppRadioGroup` 用一个稳定值管理互斥选项，并提供常规、按钮和卡片化三种展示密度。 | `form/单选框组` |
| `AppRangeControl` | `AppRangeControl` 是紧凑的原生范围输入封装，为自定义面板提供统一的尺寸、色调与键盘交互。 | `form/范围控制器` |
| `AppRate` | `AppRate` 用离散星级输入收集评价，支持半星、清空、只读展示和辅助文本。 | `form/评分` |
| `AppSearchBar` | `AppSearchBar` 以配置式字段构建列表搜索区，并将高级条件折叠为统一的查询体验。 | `form/搜索栏` |
| `AppSearchInput` | `AppSearchInput` 用于页面内的关键词搜索和搜索建议选择。它处理 Enter 提交、清空、键盘导航、建议面板和输入防抖；实际查询、建议数据与权限过滤由业务页面提供。 | `form/搜索输入框` |
| `AppSegmented` | `AppSegmented` 用于在少量平级视图或数据范围间快速切换。它采用单选组语义并支持方向键、Home 与 End 键导航，不用于提交复杂表单选项。 | `form/分段控制器` |
| `AppSelect` | `AppSelect` 提供单选、多选、本地筛选、远程检索和大量选项虚拟渲染，返回值始终与选项展示文案分离。 | `form/选择器` |
| `AppSlider` | `AppSlider` 以连续轨道输入数值，适合进度、等级、阈值和比例等具有明确范围的字段。 | `form/滑块` |
| `AppStepForm` | `AppStepForm` 将多个 `AppForm` 步骤串联，并在前进前执行字段校验和业务准入判断。 | `form/分步表单` |
| `AppSwitch` | `AppSwitch` 用于即时生效的二元状态切换，例如发布、通知与可见范围。它支持加载态和异步前置校验，避免用户连续点击造成状态错乱。 | `form/开关` |
| `AppTextarea` | `AppTextarea` 用于录入备注、简介、回复和其他多行文本，统一处理字符统计、自适应高度与错误状态。它不决定字段是否必填或内容是否合法，这些规则应由业务表单维护。 | `form/文本域` |
| `AppTimePanel` | `AppTimePanel` 是嵌入式时间列表，供业务自定义弹层或时间选择器组合使用。 | `form/时间面板` |
| `AppTimePicker` | `AppTimePicker` 通过输入框打开时间面板，并将选择结果以 `HH:mm` 文本输出。 | `form/时间选择器` |
| `AppTimeRangePicker` | `AppTimeRangePicker` 用一个起止对象表达单日时间区间，并在确认前阻止结束时间早于开始时间。 | `form/时间范围选择器` |
| `AppTimeSelect` | `AppTimeSelect` 按固定步长生成一组离散的时间点，适合选择预约、营业或排班时段。 | `form/时间选项选择器` |
| `AppTransfer` | `AppTransfer` 在来源和目标两列之间移动大量可选项，适合成员分配、权限授权和内容可见范围维护。 | `form/穿梭框` |
| `AppTreeSelect` | `AppTreeSelect` 在下拉选择器中呈现可展开的树结构，适合部门、权限与分类等层级对象的单项或多项选择。 | `form/树选择器` |

## data — 数据展示与表格（30）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppCheckTag` | `AppCheckTag` 以紧凑的标签形态管理单个布尔筛选或状态，适合不需要表单布局的快捷选择。 | `data/可选标签` |
| `AppCollapse` | `AppCollapse` 用于按需展开说明、规则和课程内容，支持多开与手风琴两种模式。 | `data/折叠面板` |
| `AppColumnSettings` | `AppColumnSettings` 用轻量弹层控制基础表格列的显示与隐藏，并可选择持久化到浏览器。 | `data/显示列设置` |
| `AppCountdown` | `AppCountdown` 根据目标时间显示实时剩余时长，并在归零时通知业务页面。 | `data/倒计时` |
| `AppCountTo` | `AppCountTo` 将数值平滑过渡到目标值，适用于经营指标、销量和金额等需要吸引注意的数字。 | `data/数字动画` |
| `AppDataListCard` | `AppDataListCard` 在卡片中展示少量关键指标，适合订单、内容和运营数据的快速概览。 | `data/数据列表卡片` |
| `AppDataTable` | `AppDataTable` 将列定义、行选择、排序、固定列、虚拟滚动和单元格插槽统一在一张可受控的数据表中。 | `data/数据表格` |
| `AppDescriptions` | `AppDescriptions` 以标签和值的形式展示订单、课程和成员等详情字段，支持密度、布局、边框及单项覆盖。 | `data/描述列表` |
| `AppEditableTable` | `AppEditableTable` 在 `AppDataTable` 的基础上提供可校验、可等待保存结果的单元格编辑流程。 | `data/可编辑表格` |
| `AppExcelExport` | `AppExcelExport` 提供统一的 Excel 导出触发按钮，不绑定任何特定数据来源。 | `data/表格导出` |
| `AppExcelImport` | `AppExcelImport` 是限定 Excel/CSV 格式的上传入口，复用上传队列与请求能力。 | `data/表格导入` |
| `AppExportTaskPanel` | `AppExportTaskPanel` 将创建导出、任务历史、失败重试与下载入口统一为紧凑操作区。 | `data/导出任务面板` |
| `AppInfiniteScroll` | `AppInfiniteScroll` 在滚动接近底部时发出加载请求，并管理加载、失败、空数据与到底提示。 | `data/无限滚动` |
| `AppPagination` | `AppPagination` 管理服务端或本地列表的页码、页大小和快速跳页，并将分页状态完全交由页面持有。 | `data/分页器` |
| `AppProgress` | `AppProgress` 展示上传、导入、任务处理等明确百分比进度，支持线形、圆形和仪表盘形态。 | `data/进度条` |
| `AppProgressCard` | `AppProgressCard` 用标题、补充说明和进度条展示一个任务的完成情况。 | `data/进度卡片` |
| `AppStatistic` | `AppStatistic` 展示格式化数值、趋势说明与可选倒计时。 | `data/统计数值` |
| `AppStatsCard` | `AppStatsCard` 用紧凑卡片呈现单个业务指标、变化趋势和辅助说明。 | `data/指标卡片` |
| `AppStatusTag` | `AppStatusTag` 用固定语义色显示简短状态文字。 | `data/状态标签` |
| `AppTableActions` | `AppTableActions` 用统一间距组合行内主操作，并把低频操作收纳到更多菜单中。 | `data/表格行操作` |
| `AppTableBatchEditor` | `AppTableBatchEditor` 依据选中行和字段配置，提供安全的批量字段修改入口。 | `data/表格批量编辑` |
| `AppTableColumnFilters` | `AppTableColumnFilters` 将多个枚举字段收纳为带搜索和计数提示的表格筛选面板。 | `data/表格列筛选` |
| `AppTableHeader` | `AppTableHeader` 将列表标题、筛选开关、刷新、密度、全屏和列显示入口组织为标准表格头部。 | `data/表格头部` |
| `AppTableOperationBar` | `AppTableOperationBar` 按固定顺序承载列筛选、视图、设置、导出及打印、全屏、刷新等表格操作。 | `data/表格操作栏` |
| `AppTableSettingsPanel` | `AppTableSettingsPanel` 用抽屉维护表格密度、斑马纹、列可见性、列顺序、宽度和冻结位置。 | `data/表格设置面板` |
| `AppTableToolbar` | `AppTableToolbar` 为表格业务操作、辅助操作和批量操作提供固定的布局分区。 | `data/表格工具栏` |
| `AppTableViewSelector` | `AppTableViewSelector` 用图标入口切换、创建、重命名和删除同一张表的命名视图。 | `data/表格视图选择器` |
| `AppTag` | `AppTag` 用可配置色调、形态和关闭行为展示分类或筛选条件。 | `data/标签` |
| `AppTree` | `AppTree` 展示层级节点，并支持受控展开、选择、勾选、筛选、懒加载和虚拟滚动。 | `data/树` |
| `AppVirtualList` | `AppVirtualList` 只渲染可视区附近的固定高度行，降低长列表的 DOM 开销。 | `data/虚拟列表` |

## navigation — 导航（15）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppAffix` | `AppAffix` 将筛选、提交等关键操作固定在滚动容器的顶部或底部，并在固定状态变化时通知页面。 | `navigation/固钉` |
| `AppAnchor` | `AppAnchor` 为同页长内容提供目录、定位与当前章节跟踪，适合文档、详情页和较长的配置页面。 | `navigation/锚点导航` |
| `AppBackToTop` | `AppBackToTop` 在页面或指定的可滚动容器越过阈值后显示一个固定操作按钮，帮助用户快速返回开头。 | `navigation/回到顶部` |
| `AppBreadcrumb` | `AppBreadcrumb` 展示当前页面在应用信息结构中的路径，并将中间层级交给业务路由处理。 | `navigation/面包屑` |
| `AppFastEnter` | `AppFastEnter` 是 `AppCommandPalette` 的导航语义封装，用于从应用任意位置快速搜索并执行入口操作。 | `navigation/快捷入口` |
| `AppGlobalSearch` | `AppGlobalSearch` 提供面向应用功能与页面的全局检索浮层，负责过滤和选择，不负责路由跳转。 | `navigation/全局搜索` |
| `AppHorizontalMenu` | `AppHorizontalMenu` 面向应用的顶部一级导航，内置二级入口浮层、激活态与外部点击关闭能力。 | `navigation/水平导航` |
| `AppMenu` | `AppMenu` 是通用的层级菜单，负责当前项、展开项与禁用项状态；路由切换由 `select` 事件交给应用处理。 | `navigation/菜单` |
| `AppMenuRight` | `AppMenuRight` 是基于上下文菜单的轻量更多操作入口，适合表格行、页面标题和卡片右上角。 | `navigation/更多菜单` |
| `AppMixedMenu` | `AppMixedMenu` 将 `AppHorizontalMenu` 与 `AppSidebarMenu` 组合为一套统一数据源的混合导航布局。 | `navigation/混合导航` |
| `AppSidebarMenu` | `AppSidebarMenu` 展示管理后台常见的树形侧栏，并在收起状态下以悬浮子菜单保留二级入口。 | `navigation/侧边导航` |
| `AppSteps` | `AppSteps` 用于呈现线性流程的进度、已完成状态和当前可处理步骤；是否允许跳转由 `clickable` 明确控制。 | `navigation/步骤条` |
| `AppTabs` | `AppTabs` 用于在同一上下文中切换少量并列内容，支持线条、卡片、边框卡片、位置调整和可编辑页签。 | `navigation/页签` |
| `AppTour` | `AppTour` 以遮罩高亮和分步浮层介绍页面功能，可定位元素并支持键盘前后切换、跳过和完成。 | `navigation/功能引导` |
| `AppWorkTab` | `AppWorkTab` 是面向后台工作区的页签封装，复用 `AppTabs` 的键盘交互与关闭能力。 | `navigation/工作区页签` |

## feedback — 反馈（14）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppAlert` | `AppAlert` 用于在当前页面内提示风险、规则变化或需要用户留意的信息，并可提供关闭与后续操作入口。 | `feedback/警告提示` |
| `AppDragVerify` | `AppDragVerify` 通过滑动确认提高高风险操作的确认成本，并同时支持鼠标、触摸和键盘操作。 | `feedback/滑动验证` |
| `AppEmptyState` | `AppEmptyState` 用于说明页面没有可展示的数据，并在合适时引导用户创建内容或调整筛选条件。 | `feedback/空状态` |
| `AppException` | `AppException` 为常见的 403、404 与 500 页面提供统一的错误信息与返回动作。 | `feedback/异常页` |
| `AppLoading` | `AppLoading` 在局部内容或整个视口等待异步结果时覆盖加载指示，避免用户误以为操作没有响应。 | `feedback/加载遮罩` |
| `AppLoadingState` | `AppLoadingState` 为列表或详情区域提供带标题和骨架行的固定加载占位。 | `feedback/加载状态` |
| `AppNetworkLoadingOverlay` | `AppNetworkLoadingOverlay` 用于跨页面请求期间的全局加载反馈，并内置延迟显示与最短展示时间以减少闪烁。 | `feedback/网络加载层` |
| `AppNotification` | `AppNotification` 以受控浮层展示通知列表，并向外通知已读和全部已读动作。 | `feedback/通知中心` |
| `AppResult` | `AppResult` 用于呈现提交、支付、导入等流程的最终状态，并给出下一步动作。 | `feedback/结果页` |
| `AppResultPage` | `AppResultPage` 是面向整页场景的 `AppResult` 包装组件，适合导入、审批等流程结束后的独立路由。 | `feedback/页面结果` |
| `AppSkeleton` | `AppSkeleton` 在内容加载期间保留主要版式，数据准备好后自动渲染默认插槽中的真实内容。 | `feedback/骨架屏` |
| `AppSkeletonItem` | `AppSkeletonItem` 是构建非标准骨架屏的最小单元，可用于文本、圆形头像和图片占位。 | `feedback/骨架项` |
| `AppStatePanel` | `AppStatePanel` 在局部业务区域统一表达空、错误、加载、权限与成功等状态，并允许替换关键内容。 | `feedback/状态面板` |
| `AppToast` | `AppToast` 将应用层维护的短时消息以固定堆叠的方式呈现，并把关闭和动作回传给业务。 | `feedback/消息提示` |

## overlay — 浮层（13）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppCommandPalette` | `AppCommandPalette` 提供可搜索、可键盘导航的全局操作入口，适合在管理后台承载快捷命令。 | `overlay/命令面板` |
| `AppConfirmDialog` | `AppConfirmDialog` 为删除、归档、发布等不可逆或有影响的操作提供统一的确认语义。 | `overlay/确认对话框` |
| `AppContextMenu` | `AppContextMenu` 将针对当前记录、文件或区域的操作收纳到点击菜单或实体右键菜单中。 | `overlay/上下文菜单` |
| `AppDialog` | `AppDialog` 用于在不离开当前页面的情况下承载编辑、确认或补充信息，内置遮罩、焦点回收和 Escape 关闭。 | `overlay/对话框` |
| `AppDrawer` | `AppDrawer` 从页面末端滑入一块独立工作区，适合筛选、详情和需要保留主页面上下文的长表单。 | `overlay/抽屉` |
| `AppDropdown` | `AppDropdown` 负责把账户、视图和记录操作组织成可键盘操作的菜单。 | `overlay/下拉菜单` |
| `AppMessageBox` | `AppMessageBox` 把确认、提醒和短文本输入统一成一个轻量流程，适合由页面动作直接唤起。 | `overlay/消息框` |
| `AppOverlay` | `AppOverlay` 是对话框、抽屉和全屏工作层共用的底层遮罩，负责 Teleport、层级和点击遮罩关闭。 | `overlay/遮罩层` |
| `AppPopconfirm` | `AppPopconfirm` 在操作入口旁就地询问用户，适合删除、移除和发布等短确认，不打断用户浏览上下文。 | `overlay/气泡确认` |
| `AppPopover` | `AppPopover` 在触发器附近展示可交互的补充内容，支持多方向定位、点击外部关闭和滚动重定位。 | `overlay/气泡卡片` |
| `AppScreenLock` | `AppScreenLock` 在用户暂时离开时遮挡工作区，并收集密码后交给业务服务校验。 | `overlay/工作区锁屏` |
| `AppSettingsPanel` | `AppSettingsPanel` 是针对工作区偏好设置的抽屉封装，复用抽屉的关闭、焦点和底部操作行为。 | `overlay/设置面板` |
| `AppTooltip` | `AppTooltip` 为图标按钮、缩写和低密度入口提供短说明，支持 hover、focus、click 和手动控制。 | `overlay/文字提示` |

## content — 内容（18）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppBasicBanner` | `AppBasicBanner` 用一行清晰的标题、说明和可选操作，承载页面级的轻量通知或状态提醒。 | `content/基础横幅` |
| `AppCardBanner` | `AppCardBanner` 用深色内容区与可选图片组织一块重点推荐内容，也可以整体作为链接入口。 | `content/卡片横幅` |
| `AppCarousel` | `AppCarousel` 用受控索引、键盘导航和触摸滑动展示一组同级视觉内容。 | `content/轮播` |
| `AppChatWindow` | `AppChatWindow` 提供固定在视口右下角的消息窗口，消息数据与回复逻辑始终由业务层控制。 | `content/聊天窗口` |
| `AppCommentWidget` | `AppCommentWidget` 渲染评论列表和输入区，并以受控数组的方式把新评论交回业务层。 | `content/评论组件` |
| `AppFestivalTextScroll` | `AppFestivalTextScroll` 是面向节日或周年活动的轻量滚动文案封装，内部复用 `AppTextScroll`。 | `content/节日文本滚动` |
| `AppFireworksEffect` | `AppFireworksEffect` 在页面中央渲染一次不可交互的庆祝粒子效果。 | `content/烟花效果` |
| `AppImage` | `AppImage` 提供固定比例、加载状态、错误回退和可选大图预览的图片展示能力。 | `content/图片` |
| `AppImageCard` | `AppImageCard` 将一张图片、标题和简短说明组合为稳定比例的内容卡片。 | `content/图片卡片` |
| `AppImageCropper` | `AppImageCropper` 允许用户选择图片、拖动定位、缩放旋转，并把裁剪结果通过事件交给业务层。 | `content/图片裁剪` |
| `AppImageViewer` | `AppImageViewer` 以对话框展示多张图片，内置切换、缩放、旋转、缩略图和下载事件出口。 | `content/图片预览器` |
| `AppRichTextEditor` | `AppRichTextEditor` 提供加粗、斜体和无序列表的轻量编辑能力，并在组件边界清洗 HTML。 | `content/富文本编辑器` |
| `AppTextScroll` | `AppTextScroll` 让一条较长的单行文字持续横向滚动，适合展示不需要立即操作的公告。 | `content/文本滚动` |
| `AppTimeline` | `AppTimeline` 将已发生或进行中的状态记录按顺序展示，并支持左右交替布局和自定义节点内容。 | `content/时间线` |
| `AppTimelineCard` | `AppTimelineCard` 把标题、说明、右侧操作和 `AppTimeline` 收拢在一张内容卡片内。 | `content/时间线卡片` |
| `AppUpload` | `AppUpload` 负责本地选择、队列状态、进度、失败重试与可选分片流程，实际文件传输由业务层注入。 | `content/上传` |
| `AppVideoPlayer` | `AppVideoPlayer` 提供带进度、音量和全屏控制的原生视频播放界面。 | `content/视频播放器` |
| `AppWatermark` | `AppWatermark` 以不可交互的重复文本覆盖固定视口或指定容器，用于提示内容来源与访问范围。 | `content/水印` |

## layout — 布局（17）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppBrandMark` | `AppBrandMark` 提供 APS Design Pro 的统一 SVG 品牌标记，可在产品导航、文档站和应用空状态中使用。 | `layout/品牌标记` |
| `AppCard` | `AppCard` 为一段关联信息建立可控的边框、标题、内容和底部操作区域，适合承载统计、列表摘要和局部配置。 | `layout/卡片` |
| `AppCol` | `AppCol` 是 24 栅格系统的列单元，通过 `span`、`offset` 和响应式断点在 `AppRow` 中定义内容宽度。 | `layout/栅格列` |
| `AppContainer` | `AppContainer` 用于搭建纵向或横向的页面骨架，并与 `AppContainerHeader`、`AppContainerMain`、`AppContainerAside`、`AppContainerFoot | `layout/容器` |
| `AppContainerAside` | `AppContainerAside` 是 `AppContainer` 横向布局中的固定宽度侧栏，提供常用宽度档位与收起状态。 | `layout/容器侧栏` |
| `AppContainerFooter` | `AppContainerFooter` 为容器底部提供统一的高度与内边距，适合放置状态说明、分页或表单操作。 | `layout/容器底部` |
| `AppContainerHeader` | `AppContainerHeader` 为容器顶部提供统一高度、横向内边距和垂直居中的内容基线。 | `layout/容器头部` |
| `AppContainerMain` | `AppContainerMain` 是纵向容器中承担剩余空间的内容区域，可选择由自身承接滚动。 | `layout/容器主体` |
| `AppDivider` | `AppDivider` 在内容分组之间提供语义化的水平或垂直边界，并可在水平分隔线上承载短标签。 | `layout/分隔线` |
| `AppHeaderBar` | `AppHeaderBar` 是应用工作区顶部的轻量标题栏，左侧显示标题和副标题，右侧保留操作插槽。 | `layout/顶部栏` |
| `AppLogo` | `AppLogo` 将 `AppBrandMark` 与产品名称组合为统一的产品标识，适合放在侧栏或导航栏起始位置。 | `layout/产品标识` |
| `AppPageContent` | `AppPageContent` 为页面的主体内容提供默认响应式内边距，并可在已具备边距的嵌入式内容中关闭它。 | `layout/页面内容` |
| `AppPageHeader` | `AppPageHeader` 用于页面或大型内容区开头的标题、说明与右侧主要操作，和 `AppHeaderBar` 的应用级标题栏用途不同。 | `layout/页面标题` |
| `AppRow` | `AppRow` 是 24 栅格系统的行容器，负责向 `AppCol` 提供列间距，并控制列组的对齐与换行。 | `layout/栅格行` |
| `AppScrollbar` | `AppScrollbar` 为局部内容提供统一的细滚动条，并通过事件和公开方法让业务层感知或控制滚动位置。 | `layout/滚动容器` |
| `AppSpace` | `AppSpace` 用 Flex `gap` 管理一组相关元素的间距，避免组件间依赖不透明的外边距规则。 | `layout/间距布局` |
| `AppSplitter` | `AppSplitter` 在两个内容区域之间提供可拖动、可键盘操作的分隔条，并以百分比受控值保存当前比例。需要收起左侧导航时，可开启内置折叠控制，不必在业务区域额外放置按钮。 | `layout/分栏面板` |

## charts — 图表（15）

| 组件 | 用途 | 文档 |
|---|---|---|
| `AppBarChart` | `AppBarChart` 固定渲染垂直柱状图，适合比较有限类目下的数值差异。 | `charts/柱状图` |
| `AppBarChartCard` | `AppBarChartCard` 将固定柱状图与指标标题收拢为后台数据卡片。 | `charts/柱状图卡片` |
| `AppChart` | `AppChart` 是所有图表类型的底层入口，负责按需创建 ECharts SVG 实例、缩放窗口和导出 SVG。 | `charts/通用图表` |
| `AppChartCard` | `AppChartCard` 将标题、说明、操作区与通用 `AppChart` 组合为仪表盘可直接使用的卡片。 | `charts/图表卡片` |
| `AppDonutChart` | `AppDonutChart` 用环形分区表达组成占比。 | `charts/环形图` |
| `AppDonutChartCard` | `AppDonutChartCard` 用固定环形图呈现组成比例，并提供卡片标题和可选操作。 | `charts/环形图卡片` |
| `AppDualBarCompareChart` | `AppDualBarCompareChart` 固定以并列柱体展示两组或多组同口径数据。 | `charts/对比柱状图` |
| `AppHBarChart` | `AppHBarChart` 固定渲染横向柱状图，便于阅读长度不一的类目名称。 | `charts/横向柱状图` |
| `AppKLineChart` | `AppKLineChart` 已保留对外组件入口，但当前通用图表内核尚未启用 OHLC 数据适配，因此会显示能力说明而非 K 线。 | `charts/K 线图` |
| `AppLineChart` | `AppLineChart` 是固定 `type="line"` 的趋势图封装，适合有连续顺序的指标变化。 | `charts/折线图` |
| `AppLineChartCard` | `AppLineChartCard` 是固定折线图类型的指标卡片，减少仪表盘中的重复配置。 | `charts/折线图卡片` |
| `AppMapChart` | `AppMapChart` 已提供稳定组件入口，但当前内核未注册具体地图 GeoJSON 数据，因而显示能力提示。 | `charts/地图图表` |
| `AppRadarChart` | `AppRadarChart` 在统一的指标维度上展示一个或多个对象的能力分布。 | `charts/雷达图` |
| `AppRingChart` | `AppRingChart` 复用组成图渲染，以环形形式呈现进度的已完成与未完成部分。 | `charts/环形进度图` |
| `AppScatterChart` | `AppScatterChart` 用离散点展示多组观测值在同一类目序列中的分布。 | `charts/散点图` |

