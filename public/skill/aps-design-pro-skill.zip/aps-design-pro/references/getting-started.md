# 快速上手（getting-started）

> aps-design-pro v0.3.1 · Vue 3 管理后台组件库 · 179 个公开组件

## 安装

```bash
npm install aps-design-pro
# 或 pnpm add aps-design-pro
```

- `vue`（^3.x）由业务应用提供（peer dependency）。
- `echarts` 会随本包自动安装（图表组件依赖）。
- 无需注册全局：按需 import 即可（组件支持 tree-shaking）。

## 引入方式

```ts
// 组件从包根导出，全部为 App 前缀 PascalCase
import { AppButton, AppDataTable, AppPagination, type DataTableColumn } from "aps-design-pro";
import "aps-design-pro/style.css"; // 样式必须引入一次（应用入口或组件所在文件）
```

```vue
<script setup lang="ts">
import { AppButton, type DataTableColumn } from "aps-design-pro";
import "aps-design-pro/style.css";

const columns: DataTableColumn<{ id: number; name: string }>[] = [
  { key: "name", label: "名称" },
];
</script>

<template>
  <AppButton>保存</AppButton>
  <AppDataTable :rows="[]" :columns="columns" row-key="id" />
</template>
```

## 关键约定（务必遵守）

1. **组件名全部以 `App` 开头**（`AppButton`、`AppDataTable`…）。这是组件库的命名约定，不要使用去掉 `App` 前缀的名称。
2. **样式必须引入**：`import "aps-design-pro/style.css"`，否则组件无样式。
3. **类型可选择性导入**：`DataTableColumn`、`DataTableSort`、`ChartSeries`、`TreeOption`、`SelectOption`、`TablePreference`、`TableView`、`ExportTask`、`UploadFileItem`、`ControlSize`、`IconName`、`TimelineItem` 等从包根导出（`import { type X } from "aps-design-pro"`）。
4. **图标名受 `IconName` 联合约束**（50 个合法值，见 `icon-names.md`）。错误的图标名会导致 TS 报错。
5. **组件不替业务发请求**：加载态（`loading`）、禁用态（`disabled`）、数据请求均由页面控制，组件只做展示与交互。
6. **CSS 变量**：组件基于 `--aps-*` CSS 变量设计（如 `--aps-blue`、`--aps-ink`、`--aps-muted`、`--aps-border`、`--aps-fill`），可通过覆盖变量实现主题定制。
7. **国际化**：`AppConfigProvider` 提供 `locale`，支持全局中文默认文案调整。
8. **受控优先**：需要同步状态的组件（表格选中、分页、展开项、浮层开关）多支持 `v-model` / `v-model:xxx`，优先使用双向绑定而非手动事件同步。

## 组件选择速查

面对一个 UI 需求时，先在 `components-index.md` 里找到对应组件再写代码：

- 单个动作 → `AppButton`；图标动作 → `AppIconButton`；链接 → `AppLink`
- 数据表格 → `AppDataTable`（配合 `AppTableToolbar`、`AppTableHeader`、`AppPagination`、`AppTableColumnFilters`）
- 表单 → `AppForm` + `AppFormField`；筛选 → `AppFilterBar` / `AppSearchBar`
- 浮层 → `AppDialog` / `AppDrawer` / `AppPopconfirm` / `AppPopover` / `AppTooltip`
- 反馈 → `AppAlert` / `AppToast` / `AppResult` / `AppSkeleton` / `AppEmptyState`
- 图表 → `AppLineChart` / `AppBarChart` / `AppDonutChart` / `AppRingChart` / `AppChartCard`

## 本地文档与类型

- 官方文档站点：仓库 `aps-design-website`，`pnpm dev` 启动。
- 组件完整 Props/Events/Slots：阅读 npm 包内 `node_modules/aps-design-pro/dist/types/components/<category>/<Component>.vue.d.ts`，这是最权威的 API 来源。
