# 核心类型（common-types）

> 以下类型均可从 `aps-design-pro` 包根导入（`import { type X } from "aps-design-pro"`）。
> 定义源自 v0.3.1 `dist/types/types/ui.d.ts`。

## 通用

```ts
export type ControlSize = "small" | "default" | "large";
export type IconName = /* 50 个合法图标字面量，见 icon-names.md */;
export type StatusTone = "success" | "warning" | "danger" | "neutral" | "info";
export type TagTone = "blue" | "green" | "orange" | "red" | "neutral";
export type TableRowKey = string | number;
export type TableSortOrder = "asc" | "desc";
export type TableDensity = "comfortable" | "compact";
export type TableColumnWidth = number | string;
export type TableColumnAlign = "left" | "center" | "right";
export type TableColumnFixed = "left" | "right";
```

## 表格

```ts
export interface DataTableColumn<TRow extends object> {
  key: Extract<keyof TRow, string>; // 行数据字段名
  label: string;
  minWidth?: TableColumnWidth;
  width?: TableColumnWidth;        // 历史兼容，新列用 defaultWidth
  defaultWidth?: number;
  maxWidth?: number;
  fixed?: TableColumnFixed;
  align?: TableColumnAlign;
  sortable?: boolean;
  resizable?: boolean;
  editable?: boolean;              // 内置单元格编辑
  editor?: DataTableEditorConfig;  // { type: "text"|"number"|"select", options?, min?, max?, step?, placeholder? }
  overflow?: "truncate" | "wrap" | "clip";
  showOverflowTooltip?: boolean;
}

export interface DataTableSort {
  key: string;
  order: TableSortOrder;
}

export interface TableColumnFilter {
  key: string;
  label: string;
  options: SelectOption[];
}
export type TableColumnFilterValues = Record<string, string[]>;

export interface TablePreference {
  version: number;
  columns: TablePreferenceColumn[]; // { key, visible, order, width?, fixed? }
  striped: boolean;
  showColumnDividers: boolean;
  density: TableDensity;
  updatedAt: number;
}
```

## 选择器与树

```ts
export interface SelectOption {
  label: string;
  value: string;
  disabled?: boolean;
  description?: string;
  group?: string;
}

export interface TreeOption {
  label: string;
  value: string;
  disabled?: boolean;
  children?: TreeOption[];
  leaf?: boolean; // 懒加载场景标识叶子节点
}
```

## 图表

```ts
export interface ChartSeries {
  name: string;
  data: number[];
  color?: string;
}
export type ChartType =
  | "line" | "bar" | "h-bar" | "donut" | "ring"
  | "radar" | "scatter" | "k-line" | "map" | "dual-bar";
```

## 上传

```ts
export interface UploadFileItem {
  uid: string;
  name: string;
  size: number;
  type: string;
  status: "ready" | "uploading" | "success" | "error" | "aborted";
  progress: number;
  url?: string;
  error?: string;
  raw?: File;
}
export type UploadBeforeUpload = (file: File, currentFiles: UploadFileItem[]) => boolean | Promise<boolean>;
export type UploadRequest = (context: UploadRequestContext) => void | Promise<void | { url: string }>;
```

## 导航与浮层 item（⚠️ 这些类型未从包根导出，只能用内联对象）

`NavigationItem`、`ContextMenuItem`、`DropdownItem`、`CommandPaletteItem`、`GlobalSearchItem`、`TabItem`、`StepItem`、`BreadcrumbItem`、`TimelineItem` 等**未从包根 re-export**。给组件传数组时直接内联对象字面量即可（TS 结构化检查通过）：

```ts
// ✅ 内联对象（icon 字段用 as const 收窄为 IconName）
const items = [
  { key: "edit", label: "编辑", icon: "edit" as const },
  { key: "delete", label: "删除", icon: "trash" as const, danger: true },
];

// ✅ 或显式局部 interface 后注解（仅当需要复用）
interface MenuRow { key: string; label: string; icon?: "edit" | "trash"; }
const rows: MenuRow[] = [{ key: "edit", label: "编辑", icon: "edit" }];
```
