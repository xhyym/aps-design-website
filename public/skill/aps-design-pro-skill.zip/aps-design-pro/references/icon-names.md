# IconName 合法图标（50 个）

> 所有需要 `icon` 属性的组件（`AppIcon`、`AppStatsCard`、`AppDataTable` 的 `emptyIcon` 等）只接受以下字面量。
> 使用不存在的图标名会导致 TS 类型报错。

`grid` · `settings` · `users` · `shield` · `menu` · `search`
`bell` · `chevron-down` · `chevron-left` · `chevron-right` · `plus` · `minus`
`dots` · `arrow-up` · `arrow-right` · `logout` · `panel` · `close`
`user` · `refresh` · `check` · `warning` · `edit` · `trash`
`columns` · `sort` · `sun` · `moon` · `lock` · `eye`
`eye-off` · `arrow-left` · `chevron-up` · `filter` · `fullscreen` · `fullscreen-exit`
`pin` · `calendar` · `clock` · `chart` · `play` · `pause`
`volume` · `volume-off` · `drag` · `download` · `print` · `zoom-in`
`zoom-out` · `copy`
