# 典型组合模式（patterns）

> 以下模式均来自官网已校验示例（vue-tsc 通过），可直接套用。

## 1. 数据表格页（最常用）

```vue
<script setup lang="ts">
import { ref } from "vue";
import {
  AppDataTable, AppPagination, AppTableToolbar,
  type DataTableColumn, type TableRowKey,
} from "aps-design-pro";
import "aps-design-pro/style.css";

interface OrderRow { id: number; no: string; customer: string; amount: number; status: string; }
const rows = ref<OrderRow[]>([
  { id: 1, no: "SO-1001", customer: "张三", amount: 1200, status: "已支付" },
]);
const columns: DataTableColumn<OrderRow>[] = [
  { key: "no", label: "订单号", defaultWidth: 140 },
  { key: "customer", label: "客户" },
  { key: "amount", label: "金额", align: "right", sortable: true, defaultWidth: 120 },
  { key: "status", label: "状态", defaultWidth: 100 },
];
const selected = ref<TableRowKey[]>([]);
const page = ref(1);
const pageSize = ref(10);
</script>

<template>
  <div>
    <AppTableToolbar :selected-count="selected.length">
      <template #bulk v-if="selected.length">
        <span>已选 {{ selected.length }} 项</span>
      </template>
    </AppTableToolbar>
    <AppDataTable
      v-model:selected-keys="selected"
      :rows="rows" :columns="columns" row-key="id"
      selectable bordered striped
    />
    <AppPagination v-model:page="page" v-model:page-size="pageSize" :total="200" />
  </div>
</template>
```

## 2. 删除确认（AppPopconfirm 包按钮）

```vue
<script setup lang="ts">
import { ref } from "vue";
import { AppPopconfirm } from "aps-design-pro";
import "aps-design-pro/style.css";

const open = ref(false);
const onConfirm = () => { /* 调接口删行 */ };
</script>

<template>
  <AppPopconfirm v-model="open" title="删除记录" description="删除后不可恢复" confirm-text="删除" danger @confirm="onConfirm">
    <template #trigger="{ toggle }">
      <button @click="toggle">删除</button>
    </template>
  </AppPopconfirm>
</template>
```

## 3. 对话框 + 表单

```vue
<script setup lang="ts">
import { ref } from "vue";
import { AppButton, AppDialog, AppForm, AppFormField, AppInput } from "aps-design-pro";
import "aps-design-pro/style.css";

const open = ref(false);
const form = ref({ name: "", email: "" });
const submit = () => { open.value = false; };
</script>

<template>
  <AppButton @click="open = true">新建用户</AppButton>
  <AppDialog v-model="open" title="新建用户">
    <AppForm :model-value="form">
      <AppFormField label="姓名" required>
        <AppInput v-model="form.name" />
      </AppFormField>
      <AppFormField label="邮箱" error="邮箱格式不正确">
        <AppInput v-model="form.email" />
      </AppFormField>
    </AppForm>
    <template #footer>
      <AppButton size="small" variant="text" @click="open = false">取消</AppButton>
      <AppButton size="small" @click="submit">保存</AppButton>
    </template>
  </AppDialog>
</template>
```

## 4. 搜索 + 筛选 + 表格

```vue
<script setup lang="ts">
import { ref } from "vue";
import {
  AppSearchBar, AppTableColumnFilters,
  type TableColumnFilterValues,
} from "aps-design-pro";
import "aps-design-pro/style.css";

const keyword = ref("");
const filters = ref<TableColumnFilterValues>({});
const filterFields = [
  { key: "status", label: "状态", options: [{ label: "启用", value: "on" }, { label: "停用", value: "off" }] },
];
const onQuery = () => { /* 触发列表查询 */ };
</script>

<template>
  <div>
    <AppSearchBar v-model="keyword" :primary-count="2" @search="onQuery" />
    <AppTableColumnFilters v-model="filters" :fields="filterFields" />
  </div>
</template>
```

## 5. 图表卡片（营收趋势）

```vue
<script setup lang="ts">
import { AppChartCard, type ChartSeries } from "aps-design-pro";
import "aps-design-pro/style.css";

const series: ChartSeries[] = [{ name: "收入", data: [88, 96, 92, 104, 118] }];
</script>

<template>
  <AppChartCard
    title="收入趋势"
    description="近五个月收入（万元）"
    type="line"
    :series="series"
    :categories="['1月', '2月', '3月', '4月', '5月']"
    exportable
  />
</template>
```

## 6. 折叠面板（受控展开）

```vue
<script setup lang="ts">
import { ref } from "vue";
import { AppButton, AppCollapse } from "aps-design-pro";
import "aps-design-pro/style.css";

const open = ref<string[]>([]);
const items = [
  { key: "a", title: "基础信息", content: "用于填写订单的基础信息。" },
  { key: "b", title: "配送信息", content: "收货地址与配送方式。" },
];
</script>

<template>
  <div>
    <AppButton size="small" @click="open = ['a', 'b']">全部展开</AppButton>
    <AppCollapse v-model="open" :items="items" />
  </div>
</template>
```

## 7. 骨架加载切换

```vue
<script setup lang="ts">
import { ref } from "vue";
import { AppButton, AppSkeleton } from "aps-design-pro";
import "aps-design-pro/style.css";

const loading = ref(true);
</script>

<template>
  <div>
    <AppButton size="small" @click="loading = !loading">切换</AppButton>
    <AppSkeleton :loading="loading" avatar :rows="3">
      <p>加载完成后的真实内容。</p>
    </AppSkeleton>
  </div>
</template>
```

## 8. 表格列筛选 + 密度（AppTableHeader）

```vue
<script setup lang="ts">
import { ref } from "vue";
import { AppTableHeader, type ControlSize } from "aps-design-pro";
import "aps-design-pro/style.css";

const visible = ref({ name: true, owner: true, amount: true });
const size = ref<ControlSize>("default");
const columnOptions = [
  { key: "name", label: "名称" },
  { key: "owner", label: "负责人" },
  { key: "amount", label: "金额" },
];
</script>

<template>
  <AppTableHeader
    v-model="visible" title="项目列表" :column-options="columnOptions"
    v-model:table-size="size"
  />
</template>
```

## 通用原则

- **表格操作组合**：`AppTableHeader`（标题/搜索/密度/列设置）→ `AppDataTable` → `AppPagination`；批量操作用 `AppTableToolbar` 的 `#bulk` 插槽或 `AppTableBatchEditor`。
- **浮层三件套**：`AppDialog`/`AppDrawer`（容器）+ `AppForm`（内容）+ `footer` 插槽（确认/取消）。
- **受控状态优先**：所有 `v-model:xxx`（`selected-keys`、`expanded-keys`、`search-visible`、`table-size`）双向绑定。
- **类型错误排查**：见 `common-types.md`；图标名见 `icon-names.md`。
